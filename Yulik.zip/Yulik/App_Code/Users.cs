﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Users
/// </summary>
public class Users
{
    public string id { get; set; }
    public string Mail { get; set; }
    public string Birthday { get; set; }
    public string FName { get; set; }
    public string LName { get; set; }
    public string Phone { get; set; }
    public string Gender { get; set; }
}
